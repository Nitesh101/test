import os
f  = os.path.getsize("inode.py")
print "print size of file: ",f

