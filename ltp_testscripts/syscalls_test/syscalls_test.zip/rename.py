import os,sys
log = open("file.log","a")
dirc = os.mkdir("/home/madisnit/Desktop
try:
	os.listdir(os.getcwd())
	os.rename
