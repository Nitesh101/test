.. _install:

============
Installation
============

This section will guide through HydraTK installation process.

.. toctree::
   :maxdepth: 1
   
   install/extensions