# -*- coding: utf-8 -*-

languages      = ['cs','en'];
language_desc  = {
  'cs' : 'Čeština',
  'en' : 'English'                
};
