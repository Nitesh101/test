#/usr/bin/python
import sys
a=sys.argv[1]
b=sys.argv[2]
sum=int (a) + int (b)
print("sum is",sum)
